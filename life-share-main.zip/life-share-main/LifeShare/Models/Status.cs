﻿namespace LifeShare.Models
{
    public enum Status
    {
        Ativo, Inativo
    }
}